#!/bin/bash

# Script para crear distribución limpia del proyecto SVAIA
# Versión: 1.0
# Fecha: 2025-06-23

echo "🚀 SVAIA - Creador de Distribución Limpia"
echo "========================================"

# Configuración
PROJECT_NAME="svaia"
VERSION=$(date +%Y%m%d-%H%M)
ZIP_NAME="${PROJECT_NAME}-v${VERSION}.zip"

echo "📦 Creando: $ZIP_NAME"
echo ""

# Verificar que estamos en el directorio correcto
if [ ! -f "run.py" ] || [ ! -d "app" ]; then
    echo "❌ Error: Ejecuta este script desde el directorio raíz del proyecto SVAIA"
    exit 1
fi

# Crear ZIP excluyendo archivos innecesarios
echo "🧹 Empaquetando archivos..."
zip -r "$ZIP_NAME" . \
    -x "*.git*" \
    -x "*venv*" \
    -x "*.venv*" \
    -x "*__pycache__*" \
    -x "*.pyc" \
    -x "*.pyo" \
    -x "*.DS_Store*" \
    -x "*uploads*" \
    -x "*test_*.py" \
    -x "*debug_*.py" \
    -x "*.log" \
    -x "*.tmp" \
    -x "*.bak" \
    -x "*config.env*" \
    -x "*.sqlite*" \
    -x "*scripts*" \
    -x "*.zip" > /dev/null

# Verificar que el ZIP se creó correctamente
if [ ! -f "$ZIP_NAME" ]; then
    echo "❌ Error: No se pudo crear el archivo ZIP"
    exit 1
fi

# Mostrar información del ZIP
echo "✅ Distribución creada exitosamente!"
echo ""
echo "📊 Información del archivo:"
echo "   Nombre: $ZIP_NAME"
echo "   Tamaño: $(ls -lh "$ZIP_NAME" | awk '{print $5}')"
echo ""

# Mostrar estadísticas del contenido
TOTAL_FILES=$(unzip -l "$ZIP_NAME" | tail -1 | awk '{print $2}')
echo "📋 Contenido:"
echo "   Total de archivos: $TOTAL_FILES"
echo ""

# Mostrar estructura principal
echo "🗂️  Estructura principal:"
unzip -l "$ZIP_NAME" | grep -E "(app/|templates/|static/|controllers/|services/)" | head -10 | awk '{print "   " $4}'
echo "   ..."
echo ""

echo "🎯 Archivos excluidos automáticamente:"
echo "   • .git/ (historial de control de versiones)"
echo "   • venv/, .venv/ (entornos virtuales de Python)"
echo "   • __pycache__/, *.pyc (archivos de cache de Python)"
echo "   • uploads/ (archivos de análisis de usuarios)"
echo "   • config.env (configuración privada con API keys)"
echo "   • *.log, *.tmp, *.bak (archivos temporales)"
echo "   • test_*.py, debug_*.py (archivos de desarrollo)"
echo "   • scripts/ (herramientas de desarrollo)"
echo ""

echo "📝 Instrucciones para el receptor:"
echo "   1. Descomprimir el archivo ZIP"
echo "   2. Crear entorno virtual: python -m venv venv"
echo "   3. Activar entorno: source venv/bin/activate"
echo "   4. Instalar dependencias: pip install -r requirements.txt"
echo "   5. Configurar config.env con API key de Gemini"
echo "   6. Ejecutar: python run.py"
echo ""

echo "🎉 ¡Distribución lista para compartir!"
echo "   Archivo: $ZIP_NAME" 